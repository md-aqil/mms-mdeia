```markdown
# Design System Strategy: The Elevated Earth

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Digital Greenhouse."** We are moving away from the rigid, boxed-in layouts of traditional e-commerce to create an editorial experience that feels curated, organic, and premium. 

To achieve this, the design system rejects standard "container-based" layouts. Instead, we utilize **Intentional Asymmetry** and **Tonal Depth**. Elements should feel as though they are placed by hand on a linen surface, not snapped to a cold digital grid. Large typography scales and overlapping imagery (e.g., a terracotta pot overlapping its background container) break the "template" look and create a signature, high-end aesthetic.

---

## 2. Colors & Surface Philosophy
The palette is rooted in a sophisticated interpretation of nature—using the warmth of terracotta (`primary`) and the tranquility of sage (`secondary`) against a foundation of cream and beige.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to define sections or cards. Structural separation must be achieved through:
- **Tonal Transitions:** Moving from `surface` (#fbfbe2) to `surface-container-low` (#f5f5dc).
- **Negative Space:** Using the Spacing Scale (specifically `12` [4rem] or `16` [5.5rem]) to create breathability.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. Use the surface tiers to create "nested" importance without shadows:
- **Level 1 (Base):** `surface` (#fbfbe2) for the main background.
- **Level 2 (In-set):** `surface-container-low` (#f5f5dc) for secondary content areas.
- **Level 3 (Prominence):** `surface-container-highest` (#e4e4cc) for high-interest callouts.

### The "Glass & Signature Texture" Rule
To add visual "soul," use `surface-tint` at low opacities with a `backdrop-blur` for navigation bars and floating modals. For Hero CTAs, utilize a subtle linear gradient from `primary` (#884d27) to `primary_container` (#a6643c) to provide a soft, sun-drenched dimension that flat color lacks.

---

## 3. Typography
The typography system balances the architectural strength of the sans-serif **Epilogue** with the literary, handcrafted feel of the serif **Newsreader**.

- **Display & Headline (Epilogue):** Used for "Brand Moments." These should be set with tight letter-spacing and high contrast in size to the body text. `display-lg` (3.5rem) should feel like a masthead.
- **Body & Title (Newsreader):** Used for storytelling and product descriptions. The serif nature conveys authority and the "hand-picked" quality of the products. 
- **Labels (Epilogue):** Set in `label-md` (0.75rem) with increased letter-spacing for a modern, functional utility feel in navigation and metadata.

---

## 4. Elevation & Depth
Depth in this system is organic, mimicking natural light hitting a matte surface.

- **The Layering Principle:** Avoid elevation shadows where possible. Instead, "stack" surface tiers. A `surface-container-lowest` (#ffffff) card sitting on a `surface-container-low` (#f5f5dc) background creates a crisp, natural lift.
- **Ambient Shadows:** When a shadow is mandatory (e.g., a floating Cart sheet), use an extra-diffused blur (24px - 40px) at 6% opacity. The shadow color must be a tinted version of `on-surface` (#1b1d0e), never pure black.
- **The "Ghost Border" Fallback:** If a boundary is required for accessibility, use `outline-variant` (#d8c2b8) at 15% opacity. High-contrast, 100% opaque borders are strictly forbidden.

---

## 5. Components

### Buttons
- **Primary:** Filled with `primary` (#884d27). Use `rounded-md` (0.75rem) for a softened, organic corner.
- **Secondary:** Outlined using the "Ghost Border" rule (15% opacity `outline-variant`).
- **Interaction:** On hover, primary buttons should shift slightly in tone to `primary_container`. No harsh "press" shadows.

### Cards & Lists
- **Rule:** Forbid the use of divider lines.
- **Cards:** Use `surface-container-low` with a padding of `5` (1.7rem) from the spacing scale.
- **Product Lists:** Separate items using vertical white space (`spacing-8`). Content hierarchy is defined by the shift from `title-lg` (Newsreader) for product names to `label-md` (Epilogue) for prices.

### Input Fields
- **Style:** Understated. A background of `surface-container-highest` with a bottom-only "Ghost Border."
- **Focus State:** The bottom border transitions to 100% opacity `primary`.

### Specialized Components: "The Botanical Overlay"
- **Pattern Masks:** Use subtle botanical SVG patterns (wheat, leaf veins) as background masks in `surface-variant` containers at 5% opacity to add texture to empty states or hero sections.

---

## 6. Do's and Don'ts

### Do:
- **Use Asymmetry:** Place product images slightly off-center within their containers to mimic a high-end lookbook.
- **Embrace White Space:** If you think there is enough space, add one more level from the spacing scale.
- **Layer Tones:** Use `surface-bright` for highlights and `surface-dim` for grounded sections.

### Don't:
- **Don't use 1px Borders:** Never use a hard line to separate content.
- **Don't use Standard Grids:** Avoid 12-column rigid alignment for imagery; allow images to span 5 or 7 columns to break the rhythm.
- **Don't use Pure Grey:** All neutrals must be tinted with the warm beige or sage green tones of the palette. Pure #888888 has no place in this system.